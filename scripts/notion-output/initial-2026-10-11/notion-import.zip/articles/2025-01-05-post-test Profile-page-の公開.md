# Profile page の公開

| 項目 | 値 |
| --- | --- |
| Jekyll source | 2025-01-05-post-test.md |
| 公開日 | 2025-01-06 |
| カテゴリ | [] |
| パーマリンク |  |
| 元記事URL | https://takuto-ando.github.io/ando_profile/post-test/ |


Webポートフォリオとしてプロフィールページを公開しました。