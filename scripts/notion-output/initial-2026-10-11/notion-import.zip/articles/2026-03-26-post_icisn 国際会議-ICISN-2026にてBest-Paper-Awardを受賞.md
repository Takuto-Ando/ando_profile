# 国際会議 ICISN 2026にてBest Paper Awardを受賞

| 項目 | 値 |
| --- | --- |
| Jekyll source | 2026-03-26-post_icisn.md |
| 公開日 | 2026-03-26T00:00:00+09:00 |
| カテゴリ | ["award"] |
| パーマリンク |  |
| 元記事URL | https://takuto-ando.github.io/ando_profile/award/post_icisn/ |


　The Sixth International Conference on Intelligent Systems and Networks (ICISN 2026) は、インテリジェントシステムとネットワークに関する最新の研究成果を共有するための国際会議です。第6回となるICISN 2026は、ベトナム・ハノイにて開催されました。

Best Paper Awardは、独創性、技術的な質、会議テーマとの関連性、そして研究コミュニティへの潜在的な影響といった点で、プログラム委員会および査読者から高く評価されました。この度、ICISN 2026のBest Paper Awardに選ばれ、表彰されました。



  ![](<../attachments/assets/images/ICISN_1.jpg>)



### 受賞研究テーマ Research theme：
　"Q-Snap: Quantization-Aware Dynamic Chunking for LLM Execution on a CGLA"

　本研究では、従来のGPUアーキテクチャにおけるLLM推論の本質的な非効率性に着目し、CGLAに最適化されたハードウェア対応スケジューリング手法を提案しています。量子化を考慮した動的チャンキングにより、FPGAプロトタイプおよび28nm ASIC想定性能において、現代のGPUシステムと比較して推論性能とエネルギー効率の双方で優れた結果を実証しました。本成果は、プロセスのスケーリングに頼らず、設計と実行によって効率向上を実現するアーキテクチャ主導の計算手法の有効性を示すものです。

**Authors:** Takuto Ando, Ayumu Takeuchi, Yu Eto, Yoshifumi Munakata, Yasuhiko Nakashima



  ![](<../attachments/assets/images/ICISN_2.PNG>)





  ![](<../attachments/assets/images/ICISN_3.png>)


