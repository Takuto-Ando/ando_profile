# 国際会議 CANDAR 2025にてBest Paper Awardを受賞

| 項目 | 値 |
| --- | --- |
| Jekyll source | 2025-11-29-post_.md |
| 公開日 | 2025-11-29T00:00:00+09:00 |
| カテゴリ | ["award"] |
| パーマリンク |  |
| 元記事URL | https://takuto-ando.github.io/ando_profile/award/post_/ |


　The Thirteenth International Symposium on Computing and Networking(CANDAR 2025)は、コンピューティングとネットワーキングのあらゆる側面における最新の研究成果と経験を共有するための国際会議です。本シンポジウムは、理論的研究から並列・分散システム、アーキテクチャ、アプリケーションの実践的な開発まで、幅広いテーマを扱います。第13回となるCANDAR 2025は、2025年11月25日(火)-28日(金)に山形県の山形テルサにて開催されました。	
Best Paper Awardは、投稿された数多くの論文の中から、最も独創性、技術的貢献度、影響力の点で優れていると評価された論文に授与される権威ある賞です。本会議での研究発表が高く評価され、今回のBest Paper Awardに選ばれました。

国際会議でBest paper awardを取ることは目標の１つでした。CANDAR’25の採択率は38％と低いうえ、さらに最優秀論文に選ばれたことは大変喜しいです。



  ![](<../attachments/assets/images/20251128_ando-1.jpg>)

 

### 受賞研究テーマ Research theme：
　"Energy-Efficient Hardware Acceleration of Whisper ASR on a CGLA"
　本研究ではWhisper等のASRの電力課題に対し、高効率なCGLA「IMAX」を用いた高速化手法を提案し、HW/SW協調設計により28nm ASIC実装でエッジGPU比1.9倍、ハイエンドGPU比9.8倍のエネルギー効率を達成しました。本成果は、エッジ環境における次世代ASRプラットフォームとしての有効性を示すものです。




  ![](<../attachments/assets/images/IMG_6011.png>)

 
