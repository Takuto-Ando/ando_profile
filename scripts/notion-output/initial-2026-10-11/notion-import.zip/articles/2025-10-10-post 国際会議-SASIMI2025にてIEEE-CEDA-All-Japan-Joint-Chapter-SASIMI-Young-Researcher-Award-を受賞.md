# 国際会議 SASIMI2025にてIEEE CEDA All Japan Joint Chapter SASIMI Young Researcher Award を受賞

| 項目 | 値 |
| --- | --- |
| Jekyll source | 2025-10-10-post.md |
| 公開日 | 2025-10-10T00:00:00+09:00 |
| カテゴリ | ["award"] |
| パーマリンク |  |
| 元記事URL | https://takuto-ando.github.io/ando_profile/award/post/ |


2025年10月10日、国際会議 SASIMI2025にてIEEE CEDA All Japan Joint Chapter SASIMI Young Researcher Award を受賞しました。




  ![](<../attachments/assets/images/sasimi2025_photo.jpg>)

 

The Workshop on Synthesis And System Integration of Mixed Information technologies (SASIMI) は、システム設計、設計経験、EDA（半導体設計自動化）、設計方法論に関する産学の情報交換の場を提供する国際会議です。理論的側面から実践的な課題、ケーススタディ、応用まで幅広いテーマで、先進的な研究成果や新しいアイデアについての発表と議論が行われます。第26回となるSASIMI 2025は、2025年10月9日(木)～10日(金)に奈良県にて開催されました。IEEE CEDA All Japan Joint Chapter SASIMI Young Researcher Awardは、本会議において優れたポスター発表を行った35歳以下の若手研究者を表彰する賞です(HP引用和訳)。

研究題目：A Detailed Analysis of LLM Execution on IMAX3 and Initial Evaluation of IMAX4 Prototype for Server Environment




  ![](<../attachments/assets/images/sasimi_award.jpg>)

 
