# 国際ジャーナル：Concurrency and Computation: Practice and ExperienceにてWhisper ASRのCGLA実装が採択されました。

| 項目 | 値 |
| --- | --- |
| Jekyll source | 2026-06-18-post_ccpe.md |
| 公開日 | 2026-06-18 09:00:00+09:00 |
| カテゴリ | ["announcement"] |
| パーマリンク |  |
| 元記事URL | https://takuto-ando.github.io/ando_profile/announcement/post_ccpe/ |


国際ジャーナル：Concurrency and Computation: Practice and Experience（Wiley）にて「Design and Evaluation of Energy-Efficient Whisper Dot-Product Kernel Offloading on a CGLA Architecture」が採択されました。
本論文はCANDAR2025にて発表した"Energy-Efficient Hardware Acceleration of Whisper ASR on a CGLA"を拡張したものです。
今回の採択により、奈良先端大にて通算２件のジャーナル採択となりました。引き続き精進します。

本研究では、音声認識モデルWhisperの中心的な演算であるDot積カーネルをCGLAアーキテクチャへ実装する手法を提案し、その設計と評価を行いました。FPGAプロトタイプによる実測および28nm ASIC推定性能の評価を通じて、エネルギー効率の観点からGPUおよびエッジAIデバイスとの比較を実施しました。一般用途向けCGLAによる音声認識ワークロードへの適用可能性を示すとともに、電力制約環境における持続可能なASR実行基盤としての有効性を実証しています。

**Authors:** Takuto Ando, Yu Eto, Ayumu Takeuchi, Yasuhiko Nakashima

**Journal:** Concurrency and Computation: Practice and Experience, Wiley, 2026
